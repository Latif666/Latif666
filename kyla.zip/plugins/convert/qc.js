import axios from 'axios';
import pkg from '@whiskeysockets/baileys';
const { MessageType } = pkg;

export default {
  name: "qc",
  command: ["qc"],
  tags: ["sticker"],
  run: async (m, { conn, prefix }) => {
    let q = m.text;

    function generateRandomColor() {
      const characters = '0123456789ABCDEF';
      let color = '#';
      for (let i = 0; i < 6; i++) {
        color += characters[Math.floor(Math.random() * 16)];
      }
      return color;
    }

    let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
    if (!teks) return m.reply(`Cara Penggunaan ${prefix}qc teks`);

    const text = `${teks}`;
    const username = await conn.getName(m.quoted ? m.quoted.sender : m.sender);
    const avatar = await conn.profilePictureUrl(m.quoted ? m.quoted.sender : m.sender, "image").catch(() => `https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`);

    const json = {
      "type": "quote",
      "format": "png",
      "backgroundColor": generateRandomColor(),
      "width": 512,
      "height": 768,
      "scale": 2,
      "messages": [
        {
          "entities": [],
          "avatar": true,
          "from": {
            "id": 1,
            "name": username,
            "photo": {
              "url": avatar
            }
          },
          "text": text,
          "replyMessage": {}
        }
      ],
    };

    try {
      const res = await axios.post(
        "https://bot.lyo.su/quote/generate",
        json,
        {
          headers: { "Content-Type": "application/json" },
        }
      );

      const buffer = Buffer.from(res.data.result.image, "base64");
     conn.sendMessage(m.chat, buffer, MessageType.sticker);
    
    } catch (error) {
      console.error(error);
      m.reply("Ada masalah dalam membuat stiker. Mohon coba lagi nanti, sayang. " + `${error}`);
    }
  }
};
