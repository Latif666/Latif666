import uploadImage from '../../system/lib/uploadImage.js'
export default {
  name: "tourl",
  command: ["tourl"],
  tags: ["convert"],
  run: async (m) => {
let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || q.mediaType || ''
	if (!mime || mime == 'conversation') return msg("media", m, true)
	let img = await q.download?.()
	let out = await uploadImage(img, true)
	if (!out) return msg("error", m, true)
	if (typeof out === 'string' || out instanceof String) m.reply(`[ LINK ]\n${out}`)
	else {
		out = out.result
		let txt = `*[ File Uploaded ]*\n`
		+ `\n*host :* ${out.host}`
		+ `\n*file_name :* ${out.filename}`
	//	+ `\n*file_size :* ${isNaN(out.filesize) ? out.filesize : niceBytes(out.filesize)}`
		+ `\n*file_url :* _${out.url}_`
		m.reply(txt)
	}
}
}
