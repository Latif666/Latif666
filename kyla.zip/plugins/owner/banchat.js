export default {
	name: "banchat",
	command: ["banchat", "unbanchat"],
	tags: ["owner"],
	run: async (m, { conn, command }) => {
		if (command == "banchat") {
            msg("done", m, true)
			global.db.chats[m.from].banned = true
		} else {
			msg("done", m, true)
			global.db.chats[m.from].banned = false
		} 
	},
	owner: true 
}