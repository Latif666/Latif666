import config from '../../config.js';

export default {
	name: "mode",
	command: ["mode"],
	tags: ["owner"],
	run: async (m, { conn }) => {
        if (!m.text) return msg("mode", m, true)
		if (m.text == "self") {
            msg("done", m, true)
			config.options.public = false 
		} else {
			msg("done", m, true)
			config.options.public = true 
		}
	},
	
	owner: true, 
};