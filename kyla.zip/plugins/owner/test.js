export default {
	name: ["test"],
	command: ["test", "bot", "halo"],
	tags: ["owner"],
	run: async (m, { conn, command }) => {
	      switch (command) {
	            
	      case 'test':
		m.reply("yes I am here!!")
		break
		case 'halo':
		m.reply("hai juga")
		break
		case 'bot':
		m.reply("iya")
		break
		default:
		
	      }
	}
};