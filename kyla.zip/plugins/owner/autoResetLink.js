export default {
 name: ["start"],
 command: ["start"],
 tags: ["owner"],
 run: async (m, { conn, command }) => {
  setInterval(async () => {
    await conn.groupRevokeInvite(m.from);
   }, 7200000);
   await m.reply("success")
 },
 owner: true,
};

