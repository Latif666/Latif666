import archiver from 'archiver';
import fs from 'fs';
import { glob } from 'glob';
import { Telegraf } from 'telegraf';
import uploadImage from '../../system/lib/uploadImage.js'
export default {
  name: "backup",
  command: ["backup"],
  tags: ["owner"],
  run: async (m, { conn }) => {
    m.reply("Tunggu ya");
    const archive = archiver('zip');
    const output = fs.createWriteStream('./backup.zip');
    const token = process.env.TELEGRAM_TOKEN
    const id = process.env.ID_TELEGRAM
    output.on('close', async () => {
      const bot = new Telegraf(token); // Replace 'YOUR_BOT_TOKEN' with your Telegram bot token
      const yourTelegramUserId = id; // Replace 'YOUR_TELEGRAM_USER_ID' with your Telegram user ID
      let kaguya = await fs.promises.readFile('./backup.zip');
      if (m.text == "tele") {
      await bot.telegram.sendDocument(yourTelegramUserId, {
        source: Buffer.from(kaguya), // Use Buffer.from to convert to Buffer
        filename: 'backup.zip'
      });
      await m.reply(`udah di tele nya, ku kirim ke id ini ${id}`)
      } else if (m.text == "link") {

      let out = await uploadImage(kaguya, true)
      	 out = out.result
		let txt = `*[ File Uploaded ]*\n`
		+ `\n*host :* ${out.host}`
		+ `\n*file_name :* ${out.filename}`
		+ `\n*file_size :* ${out.filesize}`
		+ `\n*file_url :* _${out.url}_`
		m.reply(txt)
        
	
      } else {
      await conn.sendMessage(m.from, {
        document: kaguya,
        mimetype: 'application/zip',
        fileName: 'backup.zip'
      }, {
        quoted: m
      });
      }
      fs.promises.unlink('./backup.zip', (err) => {
        if (err) throw err;
        console.log('File backup.zip telah dihapus.');
      });
    });
    archive.pipe(output);
    const filesToInclude = glob.sync('**/*', { ignore: ['node_modules/**', 'backup.zip', 'package-lock.json'] });
    filesToInclude.forEach((file) => {
      archive.file(file, { name: file });
    });
    archive.finalize();
  },
  owner: true,
  private: true
};
// :