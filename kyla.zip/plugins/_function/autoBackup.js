 import backup from "../../system/lib/autoBackup.js"

async function handler(m) {
       //auto backup 
		setInterval(() => {
  const now = Date.now();
  const nextHour = Math.ceil(now / (60 * 60 * 1000)) * (60 * 60 * 1000);
  const delay = nextHour - now;

  setTimeout(() => {
    backup();
    setInterval(() => backup(), 60 * 60 * 1000); // Set interval for subsequent backups
  }, delay);
}, 60 * 60 * 1000);
}
 export default handler;
