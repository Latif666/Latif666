export default function handler(m, { conn }) {
    const botNumber = conn.decodeJid(conn.user?.id);
    let isExcept = m.sender &&
    [...config.antiBot.isExcept, botNumber.split`@`[0]].includes(
      m.sender.replace(/\D+/g, ""),
    );
    let isAntibot = config.antiBot.isAntiBot
if (m.isBaileys && 
    !m.fromMe &&
    !isExcept &&
    isAntibot
   ) {
msg("antibot", m, true)
 conn.groupParticipantsUpdate(m.from, [m.sender], 'remove')
}
}

    