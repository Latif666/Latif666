import { canLevelUp } from '../../system/lib/levelling.js';

async function handler(m) {
	let user = global.db.users[m.sender]
	let before = user.level * 1
	while (canLevelUp(user.level, user.exp, 69))
        user.level++
   if (before !== user.level) {
   	m.reply(`
*▢ ${msg("levelUp", m, false).congrats}*

 *${before}* ‣  *${user.level}*
 
 ${msg("levelUp", m, false).checkLevel}`.trim())
   }     
}

export default handler;