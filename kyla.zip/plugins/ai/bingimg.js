import fetch from 'node-fetch';

export default {
  name: ["bingimg"],
  command: ["bingimg"],
  tags: ["image"],
 run: async (m, { conn }) => {
     if (m.text) return msg("query", m, true)
   try {
        msg("wait", m, true)
      const apiUrl = API("kaiapi", "bingimg", { prompt: m.text });
      let response = await fetch(apiUrl);
      let data = await response.json();
      data.imageLinks.forEach(async (imageUrl, index) => {
        await conn.sendFile(m.from, imageUrl, `bing_image_${index + 1}.jpg`, 'Ini gambar dari Bing!');
      });

    } catch (error) {
      console.error(error);
      msg("error", m, true)
    }
  },
};
