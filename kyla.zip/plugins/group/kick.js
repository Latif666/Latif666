export default {
	name: "kick",
	command: ["kick", "tendang"], 
	tags: "group",
	run: async (m, { conn }) => {
		try {
		let who = m.quoted ? m.quoted.sender : m.mentions && m.mentions[0] ? m.mentions[0] : m.text ? (m.text.replace(/\D/g, '') + '@s.whatsapp.net') : ''
		if (!who || who == m.sender) return msg("mentionTarget", m, true)
		if (m.metadata.participants.filter(v => v.id == who).length == 0) return msg("error", m, true)
		const data = await conn.groupParticipantsUpdate(m.from, [who], 'remove')
		m.reply(Func.format(data))
		} catch (e) {
			console.log(e)
			msg("error", m, true)
		}
	},
  group: true, 
  botAdmin: true,
  admin: true,
}