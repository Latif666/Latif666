export default {
  name: "demote",
  command: ["demote"],
  tags: ["group"],
  run: async (m, { conn }) => {
    let who = m.quoted ? m.quoted.sender : m.mentions ? m.mentions[0] : "";
    if (!who) return msg("mentionTarget", m, true)
    try {
      await conn.groupParticipantsUpdate(m.from, [who], "demote");
     msg("done", m, true)
    } catch (e) {
      console.log(e); 
    }  
  },
  group: true, 
  botAdmin: true,
  admin: true,
}; 