import pkg from '../../system/lib/remini.cjs';
const { remini } = pkg;
export default {
	name: ["hd"],
	command: ["hd", "remini", "hdr"],
	tags: ["tools"],
	run: async (m, { conn, prefix, command }) => {
		let quoted = m.quoted ? m.quoted : m;
    if (/video/.test(quoted.mime)) {
        msg("unsuportedMedia", m, true);
    } else if (/image/.test(quoted.mime)) {
      msg("wait", m, true);
      try { 
        let media = await quoted.download()
			let proses = await remini(media, "enhance");
			await conn.sendMessage(m.sender, {
				image: proses,
				caption: msg("tryAgain", m, false)
			}, {
				quoted: m
			})
          if (m.isGroup) {
          await msg("checkPrivate", m, true)
              }
      } catch (e) {
        console.log(e);
        msg("error", m, true);
      } 
     } else msg("media", m, true)
	}
}; 