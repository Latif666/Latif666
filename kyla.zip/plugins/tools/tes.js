export default {
	command: ["tes"],
	run: async (m) => {
 m.reply("")
}}