export default {
  command: ["rvo"],
  help: ["rvo"],
  tags: ["tools"],
  run: async (m, { conn, quoted }) => {
    if (!quoted.msg.viewOnce) return msg("notViewOnece", m, true)
    quoted.msg.viewOnce = false
    await conn.sendMessage(m.from, { forward: quoted }, { quoted: m })
  }
}