export default {
  command: ["tvo"],
  help: ["tvo"],
  tags: ["tools"],
  run: async (m, { conn, quoted, prefix, command }) => {
   if (/image|video/i.test(quoted.mime)){
    quoted.msg.viewOnce = true
    await conn.sendMessage(m.from, { forward: quoted }, { quoted: m })}
      else {
          msg("media", m, true)
      }
  }
}