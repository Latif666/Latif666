import ytdl from "ytdl-core"
import yts from 'yt-search'
import fs from 'fs'


export default {
	name: ["play","ytmp3","ytmp4","ytvideo"],
	command: ["play","ytmp3","ytmp4","ytvideo"],
	tags: ["download"],
	run: async (m, { conn, command, prefix }) => {
	if (!m.text) return msg("query", m, true)
    const link = m.text.match(/youtube.com/gi) ? m.text : null;
    const search = await yts(m.text)
const caption = `*YOUTUBE PLAY*'
あ ID : ${search.all[0].videoId}
あ Title : ${search.all[0].title}
あ Views : ${search.all[0].views}
あ Duration : ${search.all[0].timestamp}
あ Channel : ${search.all[0].author.name}
あ Upload : ${search.all[0].ago}
あ URL Video : ${search.videos[0].url}
あ Description : ${search.videos[0].description}
_Please wait, the audio file is being sent..._`
  	if (command==='ytmp3'||command==='play'){
let todd = await Func.getBuffer(search.all[0].image)
let gambar = await conn.sendMessage(m.from, {image: todd, caption: caption}, {quoted:m})
let ply = link ? link : search.videos[0].url;
let mp3file = `./system/temp/tmp/${m.sender}.mp3`
  let nana = await ytdl(ply, { filter: 'audioonly' })
  .pipe(fs.createWriteStream(mp3file))
  .on('finish', async () => {
await conn.sendMessage(m.from, {audio: fs.readFileSync(mp3file), mimetype:'audio/mpeg' }, {quoted: gambar})
  await fs.unlinkSync(mp3file);
  })
  } else {
  let search = await yts(m.text)
  let ply = link ? link : search.videos[0].url;
  let mp4file = `./system/temp/tmp/${m.sender}.mp4`
  let nana = await ytdl(ply, { filter: 'videoandaudio' })
  .pipe(fs.createWriteStream(mp4file))
  .on('finish', async () => {
await conn.sendMessage(m.from, {video: fs.readFileSync(mp4file), caption: caption, mimetype:'video/mp4' }, {quoted: m})
  await fs.unlinkSync(mp4file);
  })
  }}}