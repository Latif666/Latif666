import fetch from 'node-fetch';

export default {
  name: ["tiktok"],
  command: ["tiktok"],
  tags: ["download"],
  use: 'linkya , sayang.',
  run: async (m, { conn, command }) => {
    
    try {
      msg("wait", m, true)
      let url = m.text
      let response = await fetch(API("kaiapi" ,"tiktok" , { url }));
      console.log(response)
      let data = await response.json();
      let videoUrl = data.result.video.noWatermark;
      let audioUrl = data.result.music.play_url;
      let vid = await  conn.sendFile(m.from, videoUrl, createCaption(data.result), m);
      await conn.sendFile(m.from, audioUrl, {}, {quoted : vid});
    } catch (error) {
      console.error(error);
     msg('error', m, true)
    }
  },
};

 function createCaption(videoInfo) {
  return `
🎥 *Judul:* ${videoInfo.title}
📅 *Diposting pada:* ${videoInfo.created_at}
❤️ *Suka:* ${videoInfo.stats.likeCount}
💬 *Komentar:* ${videoInfo.stats.commentCount}
🔁 *Dibagikan:* ${videoInfo.stats.shareCount}
👀 *Dilihat:* ${videoInfo.stats.playCount}
💾 *Disimpan:* ${videoInfo.stats.saveCount}
🎵 *Musik:* ${videoInfo.music.title} - ${videoInfo.music.author}
🔗 *Tautan Video:* ${videoInfo.url}
  `;
}
