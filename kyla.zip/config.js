import dotenv from 'dotenv';
dotenv.config();
import {
      fileURLToPath
} from "url";
import path from 'path';
import fs from 'fs';
import chalk from 'chalk';
import moment from 'moment-timezone';
moment.tz.setDefault("Asia/Jakarta").locale("id")

const sekarang = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')

export default {
      options: {
            public: false,
            mainGroupId: "120363167989458838@g.us", /*your main group*/
            antiCall: true, // reject call
           
            database: "database.json", // End .json when using JSON database or use Mongo URI
           
            owner: ["6285334599761", "62878364240405", "6287836424040"],  // set owner number on here
          
            pairing: "",
            sessionName: "session",
    // for name session
        
            prefix: /^[°•π÷×¶∆£¢€¥®™+✓_|/~!?@#%^&.©^]/i,
            pairingNumber: "", // Example Input : 62xxx
           
            pathPlugins: "plugins",
            wm: "@Kaylaa"
      },
       antiBot:{
       isExcept: ["6287765848521", "62878364240409"],
       isAntiBot: true
      },
      autoBot: {
        isAutoRead: true
      },

      // Function Maybee
      reloadFile: (path) => reloadFile(path),

      // Rest APIs Cuy
      APIs: {
            arifzyn: "https://api.arifzyn.biz.id",
            kaiapi: "https://privatecuyyy.kaiiapi.my.id/"
      },

      APIKeys: {
            "https://api.arifzyn.biz.id": process.env.APIKEY || "",
            "https://privatecuyyy.kaiiapi.my.id/": '',
      
      },
      
      // Set pack name sticker on here
      Exif: {
            packId: "https://chat.whatsapp.com/InCDaiYvmN23dMXyAXx6bd",
            packName: null,
            packPublish: 'Kayla\n' + sekarang,
            packEmail: "@Kayla",
            packWebsite: "@Kayla",
            androidApp: "https://play.google.com/store/apps/details?id=com.bitsmedia.android.muslimpro",
            iOSApp: "https://apps.apple.com/id/app/muslim-pro-al-quran-adzan/id388389451?|=id",
            emojis: [],
            isAvatar: 0,
      }
}
  
  

      async function reloadFile(file) {
            let fileP = fileURLToPath(file);
            fs.watchFile(fileP, () => {
                  fs.unwatchFile(fileP);
                  console.log(chalk.green(`[ UPDATE ] file => "${fileP}"`));
                  import(`${file}?update=${Date.now()}`);
            });
      }

      reloadFile(import.meta.url);