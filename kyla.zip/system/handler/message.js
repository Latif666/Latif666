import('../index.js');
import config from '../../config.js';

import fs from 'fs';
import path from 'path';
import util from 'util';
import moment from 'moment-timezone';
import chalk from "chalk";
import Database from '../lib/localdb.js';
import Function from '../lib/function.js';
import replyMessage from '../lib/languages.js';
import { fileURLToPath } from "url";
import { createRequire } from "module";
const dbPath = "system/temp/database.json"
const database = new Database(dbPath)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
database.connect().catch(() => database.connect());
setInterval(async () => {
	fs.writeFileSync(dbPath, JSON.stringify(global.db, null, 3));
}, 3 * 1000);

global.API = (name, path = '/', query = {}, apikeyqueryname) => {
  const baseUrl = name in config.APIs ? config.APIs[name] : name;
  const queryParams = new URLSearchParams({
    ...(query || {}),
    ...(apikeyqueryname ? { [apikeyqueryname]: config.APIKeys[name in config.APIs ? config.APIs[name] : name] } : {})
  });
  const queryString = queryParams.toString();
  return `${baseUrl}${path}${queryString ? '?' + queryString : ''}`;
};
global.Func = Function
global.config = config
global.__dirname = __dirname
global.require = require
global.msg = replyMessage

export const Message = async (conn, m, store) => {
	try {
  	    await (await import("../lib/database.js")).idb(m);
        m.exp = 0
        m.exp += Math.ceil(Math.random() * 10) 
        const prefix = (m.prefix = /^[°•π÷×¶∆£¢€¥®™+✓_|~!?@#%^&.©^]/gi.test(m.body) ? m.body.match(/^[°•π÷×¶∆£¢€¥®™+✓_|~!?@#%^&.©^]/gi)[0]: "");
		const cmd = (m.cmd = m.body && m.body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase());
		const plugin = (m.command = plugins.get(cmd) || plugins.find((v) => v?.default.command && v.default.command.includes(cmd)));
		const quoted = m.quoted ? m.quoted : m;
        const text = m.args.join(" ")
		const today = moment.tz("Asia/Jakarta").format("dddd, DD MMMM YYYY");
        m.plugin = plugin
        let isAutoRead = config.autoBot.isAutoRead
		let group = config.options.mainGroupId
        let kode = await conn.groupInviteCode(group)
        global.linkWa = "https://chat.whatsapp.com/" + kode
		global.store = store 
        let user 

  
        
        
        await (await import ("../lib/print.js")).print(m, { conn, today, isAutoRead, command: plugin })  //print
        await (await import("../lib/register.js")).member(m, conn).member

        if (
		    !m ||
		    m.isBaileys && m.fromMe ||
		    !config.options.public && !m.isOwner ||
            m.from && global.db.chats[m.from]?.mute && !m.isOwner ||
            m.isGroup && global.db.chats[m.from].banned && !m.isOwner ||
            !db.users[m.sender].language
        ) return
 
        
        if (m.sender && (user = db.users[m.sender])) {
				user.exp += m.exp
		}
		 
        if (!plugin) {
			const dir = "plugins/_function";
			const files = fs.readdirSync(dir).filter((file) => file.endsWith(".js"));
			if (files.length === 0) return;
			for (const file of files) {
				const load = await import(`../../${dir}/${file}`)
				load.default(m, {
					conn,
					quoted,
					prefix,
					plugins,
					command: cmd,
                });
			}
        }
      
		if (plugin) {
			if ((!prefix && plugin.default.noPrefix) ||
                (!!prefix && m.body.startsWith(prefix)) || 
                (m.isOwner && !plugin.default.noPrefix))
                {
				if (plugin.default.owner && !m.isOwner) {
					return msg("owner", m, true);
                }
                if (plugin.default.group && !m.isGroup) {
                	return msg("group", m, true);
                }
                if (plugin.default.private && m.isGroup) {
                	return msg("private", m, true);
                }
                if (plugin.default.botAdmin && !m.isBotAdmin) {
                	return msg("botAndmin", m, true);
                }
                if (plugin.default.admin && !m.isAdmin) {
                	return msg("admin", m, true);
                } 
                if (plugin.default.bot && m.fromMe) {
                	return msg("bot", m, true);
                }
                if (plugin.default.premium && !m.isPremium) {
                	return msg("premium", m, true);
                }
                if (plugin.default.use && !m.text) {
                	return m.reply(plugin.default.use.replace(/%prefix/gi, prefix).replace(/%command/gi, plugin.default.name).replace(/%text/gi, m.text));
                }
                
                plugin.default.run(m, { conn, command: cmd, quoted, prefix, plugins })
                ?.then((a) => a)
				?.catch((err) => {
					let text = util.format(err);
					m.reply(`*Error Plugins*\n\n*- Name :* ${cmd}\n*- Sender :* ${m.sender.split`@`[0]} (@${m.sender.split`@`[0]})\n*- Time :* ${moment(m.timestamp * 1000).tz("Asia/Jakarta",)}\n*- Log :*\n\n${text}`, { mentions: [m.sender] });
                });
              }
            }
          } catch (e) {
		console.error(e);
    }
};

export const readCommands = async (pathname = "plugins") => {
  try {
    const dir = "plugins";
    const dirs = fs.readdirSync(dir);
    dirs
 .map(async (res) => {
        let files = fs
          .readdirSync(`${dir}/${res}`)
          .filter((file) => file.endsWith(".js"));
        for (const file of files) {
          const names = `${pathname}/${res}/${file}`	
          const plugin = await import(
            `../../${pathname}/${res}/${file}?update=${Date.now()}`
          );
          if (!plugin.default?.tags) return;
          plugins.set(names, plugin);
        }
      });
  } catch (e) {
    console.error(e);
  }
};


config.reloadFile(import.meta.url)